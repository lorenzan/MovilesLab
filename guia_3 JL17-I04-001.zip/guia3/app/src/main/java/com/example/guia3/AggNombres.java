package com.example.guia3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;

import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class AggNombres extends AppCompatActivity {

    public static String d;
    public static boolean y = false;
    EditText Nombre;
    Button Guardar;
    ProgressBar PR;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agg_nombres);

        Nombre = (EditText) findViewById(R.id.etNombre);
        PR = (ProgressBar) findViewById(R.id.PR);
        Guardar = (Button) findViewById(R.id.btnGuardar);

        Guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                d = Nombre.getText().toString();
                y = true;
                for (int i=0; i<=100; i++){
                    PR.setProgress(i, true);
                    if (i == 100){
                        finish();
                    }
                }

            }
        });

    }

}